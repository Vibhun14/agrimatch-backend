require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const OpenAI = require('openai');

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.post('/generate-tips', async (req, res) => {
  const { plants } = req.body;

  if (!plants || !Array.isArray(plants) || plants.length === 0) {
    return res.status(400).json({ error: 'Invalid or missing plant list' });
  }

  try {
    const prompt = `You're an expert in agriculture. Given the user's accepted plants: ${plants.join(", ")}, generate 3 smart planting tips. Each tip should include:
    
- title
- description
- relatedPlants (as a JSON array)
- imagePrompt (1 sentence for image generation)`;

    const completion = await openai.createChatCompletion({
      model: 'gpt-3.5-turbo',
      messages: [{ role: 'user', content: prompt }],
    });

    const output = completion.data.choices[0].message.content;

    const tips = output.split(/\n\n|\n(?=- title)/).map((block, i) => {
      const title = block.match(/title: (.+)/i)?.[1] || `Tip #${i + 1}`;
      const description = block.match(/description: (.+)/i)?.[1] || '';
      const relatedPlantsRaw = block.match(/relatedPlants: (.+)/i)?.[1] || '[]';
      const relatedPlants = JSON.parse(relatedPlantsRaw.replace(/'/g, '"'));
      const imagePrompt = block.match(/imagePrompt: (.+)/i)?.[1] || 'garden plants';

      return {
        id: `tip_${i}_${Date.now()}`,
        title,
        description,
        relatedPlants,
        imageURL: `https://source.unsplash.com/800x600/?${encodeURIComponent(imagePrompt)}`
      };
    });

    res.json(tips);
  } catch (err) {
    console.error('AI generation failed:', err);
    res.status(500).json({ error: 'Failed to generate tips' });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🌿 AgriMatch AI Tips server running on port ${PORT}`);
});
